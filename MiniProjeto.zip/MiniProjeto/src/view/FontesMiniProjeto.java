package view;

import java.awt.Font;

public class FontesMiniProjeto {
    public static Font fontePadrao = new Font("Determination Sans", Font.PLAIN, 17);
}